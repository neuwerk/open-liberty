# encoding: utf-8
BUILD_INFO = {"build_date"=>"2017-06-30T23:55:16Z", "build_sha"=>"6c2069a452c0c176b7313ac6f09d410cfeaebdb6", "build_snapshot"=>false}